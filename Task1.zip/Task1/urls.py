import django.contrib
from django.conf.urls import url
import admin
from . import views
urlpatterns = [url(r'^admin/',admin.site.urls), url(r'^input/', views.input), url(r'^$', views.output)]
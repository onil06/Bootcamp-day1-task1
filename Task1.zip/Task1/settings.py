
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'onil',
        'USER': 'onil',
        'PASSWORD': 'onil0606',
        'HOST': '',
        'PORT': '',
    }
}
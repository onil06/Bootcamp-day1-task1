from django.http import HttpResponse
from django.template import loader
from pip._vendor.urllib3 import request

def index(request):
    if request.method == 'POST':
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        contact: object = request.POST.get('contact')
        country = request.POST.get('country')
        city = request.POST.get('city')

        context = {'fname': fname,'lname': lname,'email': email,'contact': contact,'country': country,'city': city,}
        
        template = loader.get_template('output.html')
        
        return HttpResponse(template.render(context, request))
    else:
        template = loader.get_template('input.html')
        return HttpResponse(template.render())
from django import forms
import django.contrib.auth.models
from django.contrib.auth.forms import UserCreationForm

class MyForm(UserCreationForm):
    fname = forms.CharField(required = True)
    lname = forms.CharField(required = True)
    email = forms.EmailField(required=True)
    contact = forms.CharField(max_length=12, required = True)
    country = forms.CharField(required = True)
    city = forms.CharField(required=True)



